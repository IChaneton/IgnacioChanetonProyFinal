package miJava;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author tach
 */
public class DevConsulta {
    
    private boolean coincide;
    private String devUsuario;
    private String devNomyApe;

    public void setCoincide(boolean coincide) {
        this.coincide = coincide;
    }

    public boolean isCoincide() {
        return coincide;
    }

    

    
    public void setDevUsuario(String devUsuario) {
        this.devUsuario = devUsuario;
    }

    public void setDevNomyApe(String devNomyApe) {
        this.devNomyApe = devNomyApe;
    }

    public String getDevUsuario() {
        return devUsuario;
    }

    public String getDevNomyApe() {
        return devNomyApe;
    }

   
    
    
    
}
